# Tutorial Discord Bot

This is the source code for the Bot features I will be showing you how to make on YouTube.

Check out the playlist [here](https://www.youtube.com/playlist?list=PL9YUC9AZJGFG6larkQJYio_f0V-O1NRjy).

Don't forget to [subscribe](https://www.youtube.com/c/DevProTips?sub_confirmation=1)!
